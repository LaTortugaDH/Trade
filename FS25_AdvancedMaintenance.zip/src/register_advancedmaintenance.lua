if g_specializationManager:getSpecializationByName("AdvancedMaintenance") == nil then
    g_specializationManager:addSpecialization("AdvancedMaintenance", "AdvancedMaintenance", Utils.getFilename("src/advancedmaintenance.lua", g_currentModDirectory), nil);
end

for vehicleTypeName, vehicleType in pairs(g_vehicleTypeManager.types) do
    if vehicleType ~= nil and SpecializationUtil.hasSpecialization(Drivable, vehicleType.specializations) and not SpecializationUtil.hasSpecialization(Locomotive, vehicleType.specializations) then
        g_vehicleTypeManager:addSpecialization(vehicleTypeName, "AdvancedMaintenance")
        print("--- AdvancedMaintenance added --> " .. vehicleTypeName)
    else
        print("--- AdvancedMaintenance skipped --> " .. vehicleTypeName)
    end
end