-- author: DD ModPassion
-- copyright (C): DD ModPassion, All Rights Reserved
-- version: Farming Simulator 25
local modDirectory = g_currentModDirectory or "unknown"
local modName = g_currentModName
function addSpecialization()
    local modDesc = loadXMLFile("ModFile", modDirectory.."modDesc.xml")
    local numSpec = 0
    while true do
        local specKey = string.format("modDesc.specializations.specialization(%s)", numSpec)
        if not hasXMLProperty(modDesc, specKey) then
            break
        end
        local nameSpec = getXMLString(modDesc, specKey.."#name")
        local modNameSpec = modName.."."..getXMLString(modDesc, specKey.."#name")
        local infoAddedSpec01 = {}
        local infoAddedSpec02 = {}
        local nameAdd = nil
        for name, spec in pairs(g_vehicleTypeManager.types) do
            local numPre = 0
            local valPre = 0
            while true do
                local preKey = string.format(specKey..".prerequisitesPresent(%d)", numPre)
                if not hasXMLProperty(modDesc, preKey) then
                    break
                end
                local namePre = getXMLString(modDesc, preKey.."#name")
                local value = Utils.getNoNil(getXMLBool(modDesc, preKey.."#value"), "unknown")
                if value and spec.specializationsByName[namePre] ~= nil then
                    valPre = valPre + 1
                elseif not value and spec.specializationsByName[namePre] == nil then
                    valPre = valPre + 1
                elseif name == namePre then
                    if spec.specializationsByName[modNameSpec] == nil then
                        nameAdd = getXMLString(modDesc, specKey..".specialization(0)#name")
                        if nameAdd ~= nil and spec.specializationsByName[nameAdd] == nil then
                            g_vehicleTypeManager:addSpecialization(name, nameAdd)
                            g_vehicleTypeManager:addSpecialization(name, modNameSpec)
                            table.insert(infoAddedSpec02, name)
                            nameAdd = nil
                        else
                            g_vehicleTypeManager:addSpecialization(name, modNameSpec)
                            table.insert(infoAddedSpec01, name)
                        end
                    end
                    if #infoAddedSpec01 > 0 then
                        Logging.devInfo("Mod: '%s' Added specialization '%s' for vehicle type = '%s'", modName, modNameSpec, table.concat(infoAddedSpec01, " "))
                        infoAddedSpec01 = {}
                    end
                    if #infoAddedSpec02 > 0 then
                        Logging.devInfo("Mod: '%s' Added specialization '%s' and '%s' for vehicle type = '%s'", modName, modNameSpec, nameAdd, table.concat(infoAddedSpec02, " "))
                        infoAddedSpec02 = {}
                    end
                end
                numPre = numPre + 1
            end
            if valPre == numPre and valPre > 0 and spec.specializationsByName[modNameSpec] == nil
            and spec.specializationsByName[string.sub(name, 1, string.find(name, "([^.]*)$") - 2).."."..nameSpec] == nil
            and spec.specializationsByName[string.sub(name, 1, string.find(name, "([^.]*)$") - 12).."."..nameSpec] == nil then
                nameAdd = getXMLString(modDesc, specKey..".specialization(0)#name")
                if nameAdd ~= nil and spec.specializationsByName[nameAdd] == nil then
                    g_vehicleTypeManager:addSpecialization(name, nameAdd)
                    g_vehicleTypeManager:addSpecialization(name, modNameSpec)
                    table.insert(infoAddedSpec02, name)
                else
                    g_vehicleTypeManager:addSpecialization(name, modNameSpec)
                    table.insert(infoAddedSpec01, name)
                end
            end
        end
        if #infoAddedSpec01 > 0 then
            Logging.info("Mod: '%s' Added specialization '%s' for vehicle type = '%s'", modName, modNameSpec, table.concat(infoAddedSpec01, " "))
        end
        if #infoAddedSpec02 > 0 then
            Logging.info("Mod: '%s' Added specialization '%s' and '%s' for vehicle type = '%s'", modName, modNameSpec, nameAdd, table.concat(infoAddedSpec02, " "))
        end
        numSpec = numSpec + 1
    end
    delete(modDesc)
end
TypeManager.validateTypes = Utils.appendedFunction(TypeManager.validateTypes,
function(self)
    if self.typeName == "vehicle" then
        addSpecialization()
    end
end)