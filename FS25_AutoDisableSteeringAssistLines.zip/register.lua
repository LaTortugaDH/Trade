
if g_specializationManager:getSpecializationByName("AutoDisableSteeringAssistLines") == nil then
    g_specializationManager:addSpecialization('autoDisableSteeringAssistLines', 'AutoDisableSteeringAssistLines', Utils.getFilename('AutoDisableSteeringAssistLines.lua', g_currentModDirectory), nil)
end

for vehicleTypeName, vehicleType in pairs(g_vehicleTypeManager.types) do 
    if vehicleType ~= nil and not SpecializationUtil.hasSpecialization(AutoDisableSteeringAssistLines, vehicleType.specializations) and SpecializationUtil.hasSpecialization(AIAutomaticSteering, vehicleType.specializations) then
        g_vehicleTypeManager:addSpecialization(vehicleTypeName, 'autoDisableSteeringAssistLines')
    end
end
